#ifndef DEFSH
#define DEFSH

#include "set.h"
#include "sortAndSearch.h"

#endif
