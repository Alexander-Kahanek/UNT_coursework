#include <stdio.h>
#include <stdlib.h>
#include "sum.h"

int main()
{
  int a = 42, 
      b = 1701;

  printf("sum = %d\n",  sum(a, b));

  return 0;
}
