#include "defs.h"
#include "db.h"
#include "stack.h"

extern stack theStack;

extern void parseAndExecuteCommands();
